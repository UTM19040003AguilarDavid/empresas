export const environment = {
  production: true,
  baseUrl: 'https://api-tidsm-6a.herokuapp.com/api/',
  matricula: 'UTM20040085'
};
