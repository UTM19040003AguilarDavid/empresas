export class EmpresaModel
{
    _id?: string;
    strNombre: string = "";
    strRazonSocial: string = "";
    strRFC: string = "";
    strDireccion: string = "";
    strUrlLogo: string = "";
    strPais: string = "";
}