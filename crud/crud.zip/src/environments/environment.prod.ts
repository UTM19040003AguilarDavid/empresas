export const environment = {
  production: true,
  baseUrl: 'https://api-tidsm-6a.herokuapp.com/api/',
  matricula: 'UTM19040003'
};
